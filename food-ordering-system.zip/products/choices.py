CHOICES=[
    ('Delhi','Delhi'),
    ('Punjab','Punjab'),
    ('UP','UP'),
    ('HP','himachal'),
    ('Rajasthan','Rajasthan'),
    ('Kolkata','Kolkata'),
    ('Madhya Pardesh','Madhya Pardesh'),
    ('Maharastra','Maharashtra')
]