##Food ordering system: An API service for listing, ordering and delivery food programmatically.

Tools:

Django
Django Rest Framework
Ajax

API: 'localhost:8000/state/city/' 
Respose: {'restraunt': [<Restraunt: Restaurant 1>]}

API: 'localhost:8000/show/' 
Respose: {'all': <QuerySet [<new_request: shailesh>]>}


API: 'localhost:8000/profile/' 
Respose: {'profile': <UserProfile: UserProfile object (1)>}

API: 'localhost:8000/<state>/<city>/<id>/' 
Respose: {'restraunt': <Restraunt: Restaurant 1>, 'menu': <QuerySet [<Menu: Sandwich>]>, 'form': <ReviewForm bound=False, valid=Unknown, fields=(text;rating)>}

API: 'localhost:8000/<state>/<city>/<id>/' 
Method: POST
Response: {'restraunt': <Restraunt: Restaurant 1>, 'menu': <QuerySet [<Menu: Sandwich>]>, 'form': <ReviewForm bound=False, valid=Unknown, fields=(text;rating)>}

API: 'localhost:8000/order/<id>/<pk>/' 
Method: POST
Response: no delivery person is available at moment based on area availability

API: 'localhost:8000/valet/login/' 
Method: POST
Response: Order delivery request if any

API: 'localhost:8000/approve/<id>/' 
Method: POST
Response: Approve user to the platform


###Run:

Clone the project
Create virtual env using python3 virtualenv env --python=python3
Activate env source env/bin/activate
Install required modules and lib pip install requirements.txt
Run python manage.py migrate to migrate the schema to DB
Run local server: python manage.py runserver